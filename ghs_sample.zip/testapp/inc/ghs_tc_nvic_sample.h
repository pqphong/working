/*******************************************************************************
* TestApp - NVIC sample
*******************************************************************************/
#ifndef GHS_TC_NVIC_SAMPLE_H
#define GHS_TC_NVIC_SAMPLE_H

#include <stdint.h>


void ghs_tc_nvic_sample_run(void);

/* ISR */
void ghs_tc_nvic_swint0_handler(void);


#endif
