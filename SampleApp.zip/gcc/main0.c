/*******************************************************************************
* Warranty Disclaimer :
*
* Because the Product(s) is licensed free of charge, there is no warranty of
* any kind whatsoever and expressly disclaimed and excluded by Renesas, either
* expressed or implied, including but not limited to those for non-infringement
* of intellectual property, merchantability and/or fitness for the particular
* purpose. Renesas shall not have any obligation to maintain, service or provide
* bug fixes for the supplied Product(s) and/or the Application.
*
* Each User is solely responsible for determining the appropriateness of using
* the Product(s) and assumes all risks associated with its exercise of rights
* under this Agreement, including, but not limited to the risks and costs of
* program errors, compliance with applicable laws, damage to or loss of data,
* programs or equipment, and unavailability or interruption of operations.
*
* Limitation of Liability :
*
* In no event shall Renesas be liable to the User for any incidental,
* consequential, indirect, or punitive damage (including but not limited to
* lost profits) regardless of whether such liability is based on breach of
* contract, tort, strict liability, breach of warranties, failure of essential
* purpose or otherwise and even if advised of the possibility of such damages.
* Renesas shall not be liable for any services or products provided by third
* party vendors, developers or consultants identified or referred to the User
* by Renesas in connection with the Product(s) and/or the Application.
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* File Name     : main0.c
* Version       : 0.01
* Device(s)     : R-Car U5Lx
* Description   : This is the main_pe0 tutorial code.
********************************************************************************
* History : DD.MM.YYYY Version Description
*         : 30.11.2024 0.01    First Release
*******************************************************************************/
/*******************************************************************************
header include
*******************************************************************************/


/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Imported global variables and functions (from other files)
*******************************************************************************/

/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
* Outline      : PE0 Main processing
* Header       : none
* Function name: void main_pe0 (void)
* Description  : Main function sample
* Arguments    : none
* Return Value : none
*******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include "sample_fpu.h"
#include "sample_mpu.h"
#include "sample_nvic.h"



//Functions to support Fault Injection simulations
void enableFP(void);

//void enableFP (void);
void mpu_mem_manage_handler(void);
extern void mem_exception_resolve(void);
int G_nvic_exception = 0;
int G_mem_exception = 0;
volatile float FP_result;

void main_pe0(void)
{
    uint8_t mpu_region;

    mpu_region = 0x0;

    uint32_t* addressMPU = (uint32_t*) 0x204F0000;

    volatile float FP_value1 = 2.5;
    volatile float FP_value2 = 2.1;

    //FPU
    enableFP();
    FP_result = sample_fpu_001(FP_value1, FP_value2);

    //NVIC
    sample_nvic_001();

    sample_mpu_001(addressMPU, mpu_region);
	
    while(1);
}

void enableFP (void)
{

    uint32_t * cpacr_addr = (uint32_t *) 0xE000ED88;

    *cpacr_addr = *cpacr_addr | 0x00F00000;
    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");

}

void mpu_mem_manage_handler(void)
{
    // mem_exception_resolve handle memory manage
    // exception and set read/write to MPU base address
    // of mpu_region. This function resolve hang issue
    // when memory exception occurr.
    mem_exception_resolve();
    G_mem_exception = 200;
}

void Interrupt_handler(void)
{
    //Interrupt handler for SW trigger
    __asm__ volatile ("ldr r5, =0x00000000");
    __asm__ volatile ("add r5, r5, 0xA");
    G_nvic_exception = 100;
}