#ifndef SAMPLE_NVIC_H
#define SAMPLE_NVIC_H

extern void sample_nvic_001(void);

#endif