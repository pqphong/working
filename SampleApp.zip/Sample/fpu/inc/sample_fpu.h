#ifndef SAMPLE_FPU_H
#define SAMPLE_FPU_H

extern float sample_fpu_001(float input1, float input2);

#endif