#ifndef REGISTER_INFO_H
#define REGISTER_INFO_H

//Input value
#define INPUT_VAL1      0x55555555
#define INPUT_VAL2      0x0000003C
#define INPUT_VAL3      0xFFFFFFFE
#define INPUT_VAL4      0xFFFFFF00
#define INPUT_VAL5      0x000000AA
#define INPUT_VAL6      0x00000040
#define INPUT_VAL7      0x00000016
#define INPUT_VAL8      0x00000080
#define INPUT_VAL9      0x00000001
#define INPUT_VAL10      0x00010000
#define INPUT_VAL11      0x00000005
#define INPUT_VAL12      0x000000F0
#define INPUT_VAL13      0x00000000

//Define register for MPU
#define MPU_RNR                  0xE000ED98
#define MPU_RBAR                 0xE000ED9C
#define MPU_RLAR                 0xE000EDA0
#define MPU_CTRL                 0xE000ED94
#define SHCSR                    0xE000ED24
#define SHPR1                    0xE000ED18
#define MAIR0                    0xE000EDC0

#endif