#ifndef SAMPLE_MPU_H
#define SAMPLE_MPU_H

extern void sample_mpu_001(uint32_t *addressMPU, uint8_t mpu_region);

#endif